import { sAsyncProperty } from '../arbitrary/PropertySteps';

export {
  sAsyncProperty
};